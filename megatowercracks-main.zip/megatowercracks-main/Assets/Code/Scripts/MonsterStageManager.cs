using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonsterStageManager : MonoBehaviour
{
    [SerializeField] private GameObject _playerPos;
    public GameObject PlayerPos
    {
        get { return _playerPos; }
        set { _playerPos = value; }
    }
    private Color color;

    private void OnTriggerEnter2D(Collider2D collision)
    {

        if (collision.gameObject.CompareTag("Player"))
        {
            PlayerController player = (collision.gameObject.GetComponent<PlayerController>() != null) ? collision.gameObject.GetComponent<PlayerController>() : null;
            player.IsInStage = true;
            player.PlayerPos = _playerPos;
            color = GetComponent<SpriteRenderer>().material.color;
            GetComponent<SpriteRenderer>().material.color = Color.red;
        };
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            PlayerController player = collision.gameObject.GetComponent<PlayerController>();
            player.IsInStage = false;
            GetComponent<SpriteRenderer>().material.color = color;
        };
    }

    private void Awake()
    {
        color = GetComponent<SpriteRenderer>().material.color;
    }
}
