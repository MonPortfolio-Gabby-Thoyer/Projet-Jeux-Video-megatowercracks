using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;

public class PlayerController : MonoBehaviour
{
    private int _life = 10;
    private Vector2 _size;
    private bool _isInStage = false;
    private Vector3 _lastPosition;
    private bool _isDragging;
    private GameObject _playerPos;
    private int _enemyLevel;
    private bool _isInEnemyCollider;
    private PlayerLifeText _playerLifeText;
    public static PlayerController instance;
    private GameObject _enemyGameObject;

    public GameObject EnemyGameObject
    {
        get { return _enemyGameObject; }
        set { _enemyGameObject = value; }
    }
    public int PlayerHealth
    {
        get { return _life; }
        set { _life = value; }
    }
    public bool IsInStage
    {
        get { return _isInStage; }
        set { _isInStage = value; }
    }
    public GameObject PlayerPos
    {
        get { return _playerPos; }
        set { _playerPos = value; }
    }
    public int EnemyLevel
    {
        get { return _enemyLevel; }
        set { _enemyLevel = value; }
    }
    public bool IsInEnemyCollider
    {
        get { return _isInEnemyCollider; }
        set { _isInEnemyCollider = value; }
    }
    private void Awake()
    {
        _playerLifeText = FindObjectOfType<PlayerLifeText>();
        if (instance != null && instance != this)
        {
            Destroy(gameObject);
            return;
        }
        _size = GetComponent<CapsuleCollider2D>().size;
        transform.position = new Vector3(328, 127, 0);
        instance = this;
    }
    private void OnMouseDown()
    {
        _isDragging = true;
        _lastPosition = transform.position;
        GetComponent<CapsuleCollider2D>().size = new Vector2(0.1f, 0.00001f);
    }
    private void OnMouseUp()
    {
        _isDragging = false;
        if (!_isInStage)
        {
            transform.position = _lastPosition;
        }
        else
        {
            transform.position = PlayerPos.transform.position;
        }
        if (_isInEnemyCollider)
        {
            if (PlayerHealth >= _enemyLevel && IsInStage)
            {
                Destroy(_enemyGameObject);
                PlayerHealth += _enemyLevel;
            }
            else
            {
                transform.position = new Vector3(328, 127, 0);
                Destroy(gameObject);
            }
        }
        GetComponent<CapsuleCollider2D>().size = _size;

    }
    private void Update()
    {
        _playerLifeText.UpdateScore(_life);
        if (_isDragging)
        {
            Vector2 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition) - transform.position;
            transform.Translate(mousePosition);
        }
    }
}
