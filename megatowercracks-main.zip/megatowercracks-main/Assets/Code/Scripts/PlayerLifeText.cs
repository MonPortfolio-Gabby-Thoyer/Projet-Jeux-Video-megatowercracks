using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class PlayerLifeText : MonoBehaviour
{
    public GameObject scoreText;
    private TextMeshProUGUI textComponent;

    private void Awake()
    {
        // A
        textComponent = scoreText.GetComponent<TextMeshProUGUI>();
    }
    public void UpdateScore(int playerHealth)
    {
        textComponent.text = $"{playerHealth}";
    }
}
