using UnityEngine;
using UnityEngine.SceneManagement;

public class GameOverManager : MonoBehaviour
{
    public GameObject gameOverUI;
    public static GameOverManager instance;
    public void OnPlayerDeath()
    {
        gameOverUI.SetActive(true);
    }

    private void Awake()
    {
        if (instance != null)
        {
            Debug.LogWarning("Il y a plus d'une instance de GameOverManager dans la sc�ne");
            return;
        }

        instance = this;
        ///GameOverManager.instance.OnPlayerDeath(); 
        ///ajouter cette ligne dans ce qui gere la mort du perso pour faire en sorte que le menue game over apparaisse quand on meurt
    }

    public void RetryButton()
    {
        ///recommence le niveau
        ///recharge la scene
        SceneManager.LoadScene("Game");
        ///replace le joueur au spawn
        ///reactive les mouvements du joueur et + on lui rend sa vie
        
       
        ///d�sactive la scene game over quand on retry 
        gameOverUI.SetActive(false);
    }

    public void MainMenuButton()
    {
        SceneManager.LoadScene("MainMenue");
    }

    public void QuitButton()
    {
        Application.Quit();
    }
}
