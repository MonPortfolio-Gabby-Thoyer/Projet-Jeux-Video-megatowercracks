using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    public GameObject monsterPrefab;
    public int stagesCount;
    public float screenMargin = .25f;
    private float _moveStep;
    private List<int> listLevelsEnemy = new();
    public void GenerateEnemyHealth()
    {
        stagesCount = FindObjectOfType<EnemyTowerController>().stagesCount;
        int PlayerLevel = 10;
        int sumPlayerEnemies = PlayerLevel;
        System.Random number = new();

        for (int i = 0; i < stagesCount; i++)
        {
            if (listLevelsEnemy.Count == 0)
            {
                listLevelsEnemy.Add(PlayerLevel - 2);
            }
            else
            {
                listLevelsEnemy.Add(number.Next(PlayerLevel, sumPlayerEnemies));
            }
            sumPlayerEnemies += listLevelsEnemy[i];
        }
    }
    public void CreateMonsterTest()
    {
        stagesCount = FindObjectOfType<EnemyTowerController>().stagesCount;
        Camera cam = Camera.main;
        float camHeight = cam.orthographicSize;
        _moveStep = stagesCount * 70f / stagesCount;
        // Liste int maListe => �a va �tre le level de chaque monstre => avoir le m�me nombre de vies que le nombre de monstres
        // Ce level tu vas le calculer pour que ton niveau il puisse �tre faisable 

        float step = cam.transform.position.y - (camHeight / 2) + 0.2f;
        float lastStep = (cam.transform.position.y + (camHeight / 2)) - 0.2f;

        for (int i = 0; i < stagesCount; i++)
        {
            if (step >= lastStep) { break; }
            GameObject newMonster = Instantiate(monsterPrefab, new Vector3(transform.position.x, (step)), Quaternion.identity);
            newMonster.GetComponent<Monster>().Level = listLevelsEnemy[i];
            newMonster.GetComponentInChildren<TextMeshProUGUI>().text = $"{listLevelsEnemy[i]}";
            newMonster.SetActive(true);
            step += _moveStep;
        }
    }
    private void Start()
    {
        GenerateEnemyHealth();
        CreateMonsterTest();
    }
}
