using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyTowerController : MonoBehaviour
{

    public GameObject stagePrefab;
    public int stagesCount = 3;
    public float screenMargin = .25f;
    private float _moveStep;


    private void InstantiateStages()
    {
        Camera cam = Camera.main;
        float camHeight = cam.orthographicSize;
        _moveStep = stagesCount * 70f / stagesCount;

        float step = cam.transform.position.y - (camHeight / 2) + 0.75f;
        float lastStep = (cam.transform.position.y + (camHeight / 2)) - 0.75f;

        for (int i = 0; i < stagesCount; i++)
        {
            if (step >= lastStep) { break; }
            GameObject newStage = Instantiate(stagePrefab, new Vector3(transform.position.x, (step)), Quaternion.identity);
            newStage.SetActive(true);
            step += _moveStep;
        }
    }

    private void Awake()
    {
        InstantiateStages();
    }
}
