using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Monster : MonoBehaviour
{
    private int level = 0;
    public Vector3 position;
    public int Level
    {
        get { return level; }
        set { level = value; }
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            PlayerController player = other.gameObject.GetComponent<PlayerController>();
            player.IsInEnemyCollider = true;
            player.EnemyGameObject = gameObject;
            player.EnemyLevel = level;
        }
    }
    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            PlayerController player = other.gameObject.GetComponent<PlayerController>();
            player.IsInEnemyCollider = false;
        }
    }
    //private void Awake()
    //{
    //    GetComponentInChildren<TextMeshProUGUI>().text = $"{level}";
    //}
}
